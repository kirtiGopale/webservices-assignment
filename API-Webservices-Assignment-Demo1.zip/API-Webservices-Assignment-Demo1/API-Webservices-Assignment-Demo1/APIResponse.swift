//
//  APIResponse.swift
//  API-Webservices-Assignment-Demo1
//
//  Created by Apple on 22/10/26.
//

import Foundation

struct APIResponse : Decodable{
        var posts : [Post]
        var total : Int
        var limit : Int
        var skip : Int
    }


