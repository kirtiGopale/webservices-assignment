//
//  ViewController.swift
//  API-Webservices-Assignment-Demo1
//
//  Created by Apple on 22/10/26.
//

import UIKit

class ViewController: UIViewController {
                
@IBOutlet weak var postCollectionView: UICollectionView!
    
    let reuseIdentifierForCell = "PostCollectionViewCell"
    
    var urlRequest : URLRequest?
    var urlSession : URLSession?
    var posts : [Post] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initViews()
        registerCellWithTableView()
        parseJSON()
        
        print("View did load")
        
    }
    
    func initViews(){
        postCollectionView.delegate = self
        postCollectionView.dataSource = self
    }
    func registerCellWithTableView(){
        let uiNib = UINib(nibName: reuseIdentifierForCell, bundle: nil)
        self.postCollectionView.register(uiNib, forCellWithReuseIdentifier: reuseIdentifierForCell)
    }
    func parseJSON(){
        urlRequest = URLRequest(url: Constants.url!)
        urlRequest?.httpMethod = "GET"
        urlSession = URLSession(configuration: .default)
        
        let dataTask = urlSession?.dataTask(with: urlRequest!) { data,response,error in
            
            print("Data is : ",data)
            print("Response is : ",response)
            print("Error is : ",error)
            
            let jsonDecoder = JSONDecoder()
           
            do {
                let jsonDecoder = JSONDecoder()

                let apiResponse = try jsonDecoder.decode([Post].self,from: data!)

                print("Total posts:", apiResponse.count)

                DispatchQueue.main.async {
                    self.posts = apiResponse
                    self.postCollectionView.reloadData()
                }

            } catch {
                print("error")
            }
        }
        dataTask?.resume()
    }
}

extension ViewController : UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout{
    
    func collectionView(_ collectionView: UICollectionView,numberOfItemsInSection section: Int) -> Int {
        return posts.count
    }
    func numberOfSections(in collectionView: UICollectionView) -> Int {
        return 1
    }
    func collectionView(_ collectionView: UICollectionView,cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let postCollectionViewCell = collectionView.dequeueReusableCell(withReuseIdentifier: reuseIdentifierForCell,for: indexPath) as? PostCollectionViewCell
        
        
        
        postCollectionViewCell?.postUserIdLabel.text = "\(posts[indexPath.item].userId)"
        postCollectionViewCell?.postIdLabel.text = "\(posts[indexPath.item].id)"
        postCollectionViewCell?.postTitleLabel.text = "\(posts[indexPath.item].title)"
        postCollectionViewCell?.postBodylabel.text = "\(posts[indexPath.item].body)"
        
        return postCollectionViewCell ?? UICollectionViewCell()
    }
    
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let collectionViewWidth = self.postCollectionView.frame.width
        let minimumSpacing = 10.0
        let widthavialable = collectionViewWidth - minimumSpacing * 4.0
        
        return CGSize(width: widthavialable/2.0, height: widthavialable/2.0)
    }
}

