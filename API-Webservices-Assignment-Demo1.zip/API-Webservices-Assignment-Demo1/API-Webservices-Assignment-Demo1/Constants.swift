//
//  Constants.swift
//  API-Webservices-Assignment-Demo1
//
//  Created by Apple on 22/10/26.
//

import Foundation

struct Constants {
    static let url = URL(string: "https://jsonplaceholder.typicode.com/posts")
}

