//
//  PostCollectionViewCell.swift
//  API-Webservices-Assignment-Demo1
//
//  Created by Apple on 22/10/26.
//

import UIKit

class PostCollectionViewCell: UICollectionViewCell {

    @IBOutlet weak var postUserIdLabel: UILabel!
    @IBOutlet weak var postIdLabel: UILabel!
    @IBOutlet weak var postTitleLabel: UILabel!
    @IBOutlet weak var postBodylabel: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
        
    }

}
