//
//  Post.swift
//  API-Webservices-Assignment-Demo1
//
//  Created by Apple on 22/10/26.
//

import Foundation

struct Post: Decodable {
    let userId: Int
    let id: Int
    let title: String
    let body: String
}
