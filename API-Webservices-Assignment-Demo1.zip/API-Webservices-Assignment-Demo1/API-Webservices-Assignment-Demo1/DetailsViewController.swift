//
//  DetailsViewController.swift
//  API-Webservices-Assignment-Demo1
//
//  Created by Apple on 22/10/26.
//

import UIKit

class DetailsViewController: UIViewController {

    @IBOutlet weak var postUserIdLabel: UILabel!
    @IBOutlet weak var postIdLabel: UILabel!
    @IBOutlet weak var postTitleLabel: UILabel!
    @IBOutlet weak var postBodyLabel: UILabel!
    
    var selectedPost: Post?
    
    override func viewDidLoad() {
        super.viewDidLoad()
       displayPostDetails()
        
    }
    func displayPostDetails() {

           guard let post = selectedPost else {
               return
           }

           postUserIdLabel.text = "\(post.userId)"
           postIdLabel.text = "\(post.id)"
           postTitleLabel.text = post.title
           postBodyLabel.text = post.body
       }

  

}
